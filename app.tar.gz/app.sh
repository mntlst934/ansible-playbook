#/bin/bash
perl -MPOSIX -e '$0="dummpy process"; pause' &