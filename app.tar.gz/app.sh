#/bin/bash
perl -MPOSIX -e '$0="dummy process"; pause' &
